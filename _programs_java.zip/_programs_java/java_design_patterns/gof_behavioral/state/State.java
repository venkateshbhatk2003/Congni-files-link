package java_design_patterns.gof_behavioral.state;

interface State {
    void doAction(Context context);
}
