package java_design_patterns.gof_behavioral.iterator;

public interface Container {

    Iterator getIterator();
}
