package java_design_patterns.gof_structural.flyweight;

public interface Shape {
    void draw();
}