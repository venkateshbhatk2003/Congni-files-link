package java_design_patterns.gof_structural.bridge;

public interface Workshop {
    void work();
}
