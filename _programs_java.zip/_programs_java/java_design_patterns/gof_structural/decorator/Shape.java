package java_design_patterns.gof_structural.decorator;

public interface Shape {
    void draw();
}
