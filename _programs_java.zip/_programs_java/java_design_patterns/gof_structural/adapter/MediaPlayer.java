package java_design_patterns.gof_structural.adapter;

public interface MediaPlayer {
    void play(String audioType, String fileName);
}
