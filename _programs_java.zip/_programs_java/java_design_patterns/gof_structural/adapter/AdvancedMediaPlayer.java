package java_design_patterns.gof_structural.adapter;

interface AdvancedMediaPlayer {
     void playVlc(String fileName);
     void playMp4(String fileName);
}
