package java_design_patterns.gof_creational.factory;

public class InstitutionalPlan extends Plan {

    @Override
    protected void setRate() {
        rate = 4.5;
    }
}
