package java_design_patterns.gof_creational.prototype;

public interface Prototype {
    Prototype getClone();
}
