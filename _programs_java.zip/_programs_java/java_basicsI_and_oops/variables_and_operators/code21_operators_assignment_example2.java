class OperatorExample{  
public static void main(String[] args){  
int a=10;  
a+=3;//10+3  
System.out.println(a);  
a-=4;//13-4  
System.out.println(a);  
a*=2;//9*2  
System.out.println(a);  
a/=2;//18/2  
System.out.println(a);  
}}  